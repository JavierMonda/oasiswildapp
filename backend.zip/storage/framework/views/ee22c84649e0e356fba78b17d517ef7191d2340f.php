<?php $__env->startSection('content'); ?>
	<!-- SpanishForm -->
    <div class="modal fade" id="español" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Español</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form>
              <label for="recipient-name" class="col-form-label">
                <ul>
                  <li>Por favor, evalúe su satisfacción general con los servicios del restaurante:</li>
                </ul>
              </label>
              <div class="form-group">                
                <label class="checkeable">
              <input type="checkbox" name="cap1"/>
              <img src="img/01.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/02.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/03.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/04.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/05.png"/>
            </label>
          </div>
          <label for="recipient-name" class="col-form-label">
                <ul>
                  <li>Los empleados fueron amables:</li>
                </ul>
              </label>
              <div class="form-group">                
                <label class="checkeable">
              <input type="checkbox" name="cap1"/>
              <img src="img/01.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/02.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/03.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/04.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/05.png"/>
            </label>
          </div>
          <label for="recipient-name" class="col-form-label">
                <ul>
                  <li>Me sirvieron de manera rápida:</li>
                </ul>
              </label>
              <div class="form-group">                
                <label class="checkeable">
              <input type="checkbox" name="cap1"/>
              <img src="img/01.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/02.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/03.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/04.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/05.png"/>
            </label>
          </div>
          <label for="recipient-name" class="col-form-label">
                <ul>
                  <li>La calidad de la comida fue buena y a buen precio:</li>
                </ul>
              </label>
              <div class="form-group">                
                <label class="checkeable">
              <input type="checkbox" name="cap1"/>
              <img src="img/01.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/02.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/03.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/04.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/05.png"/>
            </label>
          </div>
          <label for="recipient-name" class="col-form-label">
                <ul>
                  <li>Las instalaciones son confortables:</li>
                </ul>
              </label>
              <div class="form-group">                
                <label class="checkeable">
              <input type="checkbox" name="cap1"/>
              <img src="img/01.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/02.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/03.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/04.png"/>
            </label>
            <label class="checkeable">
              <input type="checkbox" name="cap2"/>
              <img src="img/05.png"/>
            </label>
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">Deje su sugerencia o comentario:</label>
            <textarea class="form-control" id="message-text"></textarea>
          </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            <a href="gracias.html">
              <button type="button" class="btn btn-primary">Enviar</button>
            </a>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/encuestas/resources/views/createES.blade.php ENDPATH**/ ?>