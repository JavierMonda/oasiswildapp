<?php $__env->startSection('content'); ?>
<!-- Header -->
<header class="masthead d-flex">
  <div class="container text-center my-auto">
    <img class="logo" src="../img/logo.jpg">
    <h1 class="mb-1">¡Tu opinión nos importa!</h1>
    <h3 class="mb-5">
      <em>Seleccione una opción</em> / <em>Select an option</em>
    </h3>
    <div class="row encuestas-index">

      <div class="col-md-4 div-texto-centrado">       
        <img class="img img-responsive img-restaurante" alt="Restaurante Oasis - Oasis Wildlife" src="../img/restauranteOasis.jpg">
        <a href="<?php echo e(url('/encuestas/restaurants/oasis')); ?>">
          <h3 class="mb-5"><em>Restaurante Oasis</em></h3>
        </a>
      </div>

      <div class="col-md-4 div-texto-centrado">
        <img class="img img-responsive img-restaurante" alt="Restaurante Leones Marinos - Oasis Wildlife" src="../img/restauranteLeones.jpg">
        <a href="<?php echo e(url('/encuestas/restaurants/leones')); ?>">
          <h3 class="mb-5"><em>Restaurante Leones Marinos</em></h3>
        </a>
      </div>

      <div class="col-md-4 div-texto-centrado">
        <img class="img img-responsive img-restaurante" alt="Restaurante Patio Majorero - Oasis Wildlife" src="../img/restaurantePatio.jpg">
        <a href="<?php echo e(url('/encuestas/restaurants/patio')); ?>">         
          <h3 class="mb-5"><em>Restaurante Patio Majorero</em></h3>
        </a>
      </div>

    </div>
  </div>
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/encuestas/resources/views/encuestas/oasis.blade.php ENDPATH**/ ?>