<?php $__env->startSection('content'); ?>
<!-- Header -->
<header class="masthead d-flex">
  <div class="container text-center my-auto">
    <img class="logo" src="img/logo.jpg">
    <h1 class="mb-1">¡Tu opinión nos importa!</h1>
    <h3 class="mb-5">
      <em>Seleccione una opción</em> / <em>Select an option</em>
    </h3>
    <a href="<?php echo e(url('/encuestas/restaurants/oasis')); ?>">
      <img class="restaurante" src="img/restauranteOasis.jpg">
    </a>
    <h3 class="mb-5"><em>Restaurante Oasis</em></h3>
    <a href="<?php echo e(url('/encuestas/restaurants/leones')); ?>">
      <img class="restaurante" src="img/restauranteLeones.jpg">
    </a>
    <h3 class="mb-5"><em>Restaurante Leones Marinos</em></h3>
    <a href="<?php echo e(url('/encuestas/restaurants/patio')); ?>">
      <img class="restaurante" src="img/restaurantePatio.jpg">
    </a>
    <h3 class="mb-5"><em>Restaurante Patio Majorero</em></h3>
  </div>
  <div class="overlay"></div>
</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/encuestas/resources/views/encuestas/index.blade.php ENDPATH**/ ?>