<?php $__env->startSection('content'); ?>
	<header class="masthead d-flex">

		<div class="container text-center my-auto">
			<img class="logo" src="img/logo.jpg">
		  <h1 class="mb-1">Gracias!!</h1>
		  <h3 class="mb-5">
		    <em>Su opinión nos ayuda a seguir mejorando!</em>
		  </h3>
		</div>
		<div class="overlay"></div>
	</header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/encuestas/resources/views/gracias.blade.php ENDPATH**/ ?>