@extends('layouts.layout')
@section('content')
	<header class="masthead d-flex">

		<div class="container text-center my-auto">
			<img class="logo" src="img/logo.jpg">
		  <h1 class="mb-1">Dziękuję!!</h1>
		  <h3 class="mb-5">
		    <em>Twoja opinia pomaga nam ulepszać!</em>
		  </h3>
		</div>
		<div class="overlay"></div>
	</header>
@endsection